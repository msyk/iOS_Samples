//
//  LocalDB.swift
//  CoreDataSample_Swift
//
//  Created by Masayuki Nii on 2015/07/13.
//  Copyright (c) 2015年 Masayuki Nii. All rights reserved.
//

import UIKit
import CoreData

class LocalDB: NSObject {
    
    var moContext: NSManagedObjectContext = NSManagedObjectContext()
    var entityDescPeople: NSEntityDescription?
    
    func setuCoreData() {
        var error: NSError? = nil;
        let modelURL: NSURL! = NSBundle.mainBundle().URLForResource("Model", withExtension: "momd");
        let model: NSManagedObjectModel? = NSManagedObjectModel(contentsOfURL: modelURL);
        if let managedModel = model {
            let pStoreCoordinator: NSPersistentStoreCoordinator?
            = NSPersistentStoreCoordinator(managedObjectModel: managedModel);
            
            let fm: NSFileManager = NSFileManager.defaultManager();
            let storeURLs = fm.URLsForDirectory(NSSearchPathDirectory.DocumentDirectory,
                inDomains: NSSearchPathDomainMask.UserDomainMask);
            var storeURL: NSURL = storeURLs[0] as NSURL;
            storeURL = storeURL.URLByAppendingPathComponent("localdb.sqlite");
            
            if let coordinator = pStoreCoordinator {
                let pStore :NSPersistentStore?
                do {
                    pStore = try coordinator.addPersistentStoreWithType(NSSQLiteStoreType,
                        configuration: nil, URL: storeURL, options: nil)
                } catch var error1 as NSError {
                    error = error1
                    pStore = nil
                };
                if (error != nil)   {
                    print(error?.description);
                    return;
                }
                
                self.moContext = NSManagedObjectContext();
                self.moContext.persistentStoreCoordinator = coordinator;
                self.entityDescPeople = NSEntityDescription.entityForName("Person",
                    inManagedObjectContext: self.moContext);
            }
        }
    }
    
    func getFromServer()    {
        var error: NSError? = nil;
        let urlToAccess = NSURL(string: "https://server.msyk.net/apitest/index.php?op=R")
        if let url = urlToAccess {
            let request = NSURLRequest(URL: url)
            let config = NSURLSessionConfiguration.ephemeralSessionConfiguration();
            let session = NSURLSession(configuration: config);
            let task = session.dataTaskWithRequest(request,
                completionHandler:
                {(data: NSData?, res: NSURLResponse?, er: NSError?) -> Void in
                    if let dataDL = data {
                        let dataArray: AnyObject!
                        do {
                            dataArray = try NSJSONSerialization.JSONObjectWithData(dataDL,
                                options: NSJSONReadingOptions.MutableContainers)
                        } catch _ {
                            dataArray = nil
                        }
                        //println(NSString(data: data, encoding: NSUTF8StringEncoding))
                        for currentRecord in dataArray as! NSArray {
                            print(currentRecord)
                            let obj: AnyObject = NSEntityDescription.insertNewObjectForEntityForName("Person", inManagedObjectContext: self.moContext)
                            let aPerson = obj as! Person
                            if let optionalValue: AnyObject? = currentRecord["name"]    {
                                if let value: AnyObject = optionalValue    {
                                    if (value.isKindOfClass(NSNull))    {
                                        aPerson.name = ""
                                    }
                                
                                else {
                                    aPerson.name = optionalValue as! String!
                                }
                                }
                            }
                            if let optionalValue: AnyObject? = currentRecord["yomi"]    {
                                if let value: AnyObject = optionalValue    {
                                    if (value.isKindOfClass(NSNull))    {
                                        aPerson.yomi = ""
                                    }
                                
                                else {
                                    aPerson.yomi = optionalValue as! String!
                                }
                                }
                            }
                            if let optionalValue: AnyObject? = currentRecord["tel"]    {
                                if let value: AnyObject = optionalValue    {
                                    if (value.isKindOfClass(NSNull))    {
                                        aPerson.tel = ""
                                    }
                                
                                else {
                                    aPerson.tel = optionalValue as! String!
                                }
                                }
                            }
                            if let optionalValue: AnyObject? = currentRecord["cellphone"]    {
                                if let value: AnyObject = optionalValue    {
                                    if (value.isKindOfClass(NSNull))    {
                                        aPerson.cellphone = ""
                                    }
                                
                                else {
                                    aPerson.cellphone = optionalValue as! String!
                                }
                                }
                            }
                        }
                        do {
                            try self.moContext.save()
                        } catch var error1 as NSError {
                            error = error1
                        } catch {
                            fatalError()
                        };
                    }
            })
            task?.resume()
        }
    }
    
    func allData() -> [AnyObject]?    {
        var error: NSError? = nil;
        
        let resuest = NSFetchRequest(entityName: "Person");
        let result: [AnyObject]?
        do {
            result = try self.moContext.executeFetchRequest(resuest)
        } catch var error1 as NSError {
            error = error1
            result = nil
        }
        return result
    }
    
}
