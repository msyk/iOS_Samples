//
//  Person.swift
//  
//
//  Created by Masayuki Nii on 2015/07/13.
//
//

import Foundation
import CoreData

class Person: NSManagedObject {

    @NSManaged var name: String
    @NSManaged var yomi: String
    @NSManaged var tel: String
    @NSManaged var cellphone: String

}
